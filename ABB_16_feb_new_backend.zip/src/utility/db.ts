import { Client } from 'pg';

const client = new Client({
  // connectionString : 'postgres://ziwlmbxqugiatg:9194fb3f2829496b6bb5e1cc9ea8dba6c3f9b705d7e250b73d6fbdc0ea793e34@ec2-54-225-254-115.compute-1.amazonaws.com:5432/d1tqnjag5dm5br',
  connectionString : 'postgres://yccjawtjcylujr:e8e9294e92ca5387a7293d68f21a0d1f677bbd0463caa921c2066daf264a8c59@ec2-3-211-245-154.compute-1.amazonaws.com:5432/d33hiarduoj66n',
  ssl: {
    rejectUnauthorized: false
  }
});
client.connect();
export default client;