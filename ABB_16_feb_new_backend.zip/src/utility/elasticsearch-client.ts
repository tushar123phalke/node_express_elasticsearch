// const elasticsearch = require('elasticsearch');
// const connectionString = process.env.SEARCHBOX_URL;

// const client = new elasticsearch.Client({
//     host: connectionString
// });

// export default client;