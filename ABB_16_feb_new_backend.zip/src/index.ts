import express from "express";
import axios from "axios";
// tslint:disable-next-line:no-var-requires
const Webex =  require('webex');
// tslint:disable-next-line:no-var-requires
const cors = require('cors');
import bodyParser from 'body-parser';
import { HealthCloudga } from './controller/healthcloudga';
import { Book } from './controller/book';
import db from './utility/db';
import elasticsearch = require('elasticsearch');
import { RssFeeds } from "./controller/rss-feeds";

const connectionString = 'https://paas:efd88bfa98e2967b80f355ab07c0cd57@oin-us-east-1.searchly.com';

const Client = new elasticsearch.Client({
    host: connectionString
});

const webex = Webex.init({
    meetings: {
        reconnection: {
          enabled: true
        },
        enableRtx: true
    },
    credentials: {
      access_token: 'NWYzNWJhZjgtNjc2OC00OWNkLWJkYzMtZWY0ZTYzMDVkODIxN2Q3ZGFmMDctMmM0_P0A1_77d2afa7-517c-48a4-8826-a1e760aefa35'
    }
});

/*webex.meetings.register().catch((err: any) => {
    // tslint:disable-next-line:no-console
    console.error(err);
    alert(err);
    throw err;
  });*/

const app = express();
const port = 8084; // default port to listen
app.use(cors());

// Postgres
const healthCloudga = new HealthCloudga();
const book = new Book();
const rssFeeds = new RssFeeds();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(bodyParser.raw());

const router: express.Router = express.Router();
app.use('/healthcare', healthCloudga.router);
app.use('/booksdetails', book.router);
app.use('/feeds', rssFeeds.router)

///////////////////////////////

// create application/json parser
const jsonParser = bodyParser.json()

// create application/x-www-form-urlencoded parser
const urlencodedParser = bodyParser.urlencoded({ extended: false })

// define a route handler for the default home page
app.get( "/userdetails", ( req, res ) => {
    webex.people.get('Y2lzY29zcGFyazovL3VzL1BFT1BMRS8yOGZkMjc2ZC1hNjFlLTQyOTgtOGY5NC01YTJhYzgyYzQ3Y2I')
    .then((result: any) => {
        res.send(result);
    });
});


app.get("/meetinglist", ( req, res ) => {
    webex.meetings.getAllMeetings({})
    .then((result: any) => {
        res.send(webex.meetings);
    });
});


app.get("/additem", (req, res) => {
    Client.index({
        index: 'abbott_book',
        type: 'document',
        id: '3',
        body: {
                book_name: 'Math 1',
                book_text: 'Math is improved if multiple redundant sites are used, which makes well-designed cloud computing suitable for business continuity.',
                book_desc: 'Math 1....',
                book_url: 'http://sample1math.com'
        }
      },  (error: any, response: any) => {
            res.send(response);
      });
})


app.get("/searchitem/:searchstring", (req, res) => {
    let queryObj = null;
    // tslint:disable-next-line:no-console
    console.log(req.params.searchstring);
    if (req.params.searchstring !== 'null') {
        queryObj = {
            query : {
                query_string:{
                    query: req.params.searchstring
                }
            }
        };
    }  else {
        queryObj = {
            query: {
                match_all: {}
            },
            size: 500
        };
    }
    Client.search({
        index: 'abbott_book',
        type: 'document',
        body: queryObj
    }).then( (resp) => {
        res.send(resp);
    }, (err) => {
        res.send(err.message);
    });
})


// app.get("/searchitem/:searchstring", (req, res) => {

//     Client.search({
//         index: 'abbott_book',
//         type: 'document',
//         body: {
//             query: {
//                 query_string:{
//                    // query: req.params.searchstring
//                    // "term":{"book_name":req.params.searchstring}
//                 }
//             }
//         }
//     }).then( (resp) => {
//         res.send(resp);
//     }, (err) => {
//         res.send(err.message);
//     });
// })




// app.get("/searchitem/getall", (req, res) => {
//     Client.search({
//         index: 'abbott_book',
//         type: 'document',
//         body: {
//             query: {
//                 query_string:{
//                    query: req.params.searchstring
//                 }
//             }
//         }
//     }).then( (resp) => {
//         res.send(resp);
//     }, (err) => {
//         res.send(err.message);
//     });
// })

app.get('/books/getall', jsonParser, (req, res ) => {

    Client.search({
        index: 'abbott_book',
        type: 'document',
        body: {
            query: {
                match_all: {}
                // query_string:{
                //    query: 'eu'
                // }
            },
            size: 500
        }
    }).then( (resp) => {
        res.send(resp);
    }, (err) => {
        res.send(err.message);
    });
});








app.get( "/teams", ( req, res ) => {
    webex.teams.list({
        max: 10
    }).then((result: any) => {
        // tslint:disable-next-line:no-console
        // console.log(result.items);
        res.send(result.items);
    });
});

app.get('/meetings', ( req, res ) => {
    axios({
        method: 'get',
        url: 'https://webexapis.com/v1/meetings',
        headers: {'Content-Type': 'application/json',
         'Authorization': 'Bearer NWYzNWJhZjgtNjc2OC00OWNkLWJkYzMtZWY0ZTYzMDVkODIxN2Q3ZGFmMDctMmM0_P0A1_77d2afa7-517c-48a4-8826-a1e760aefa35'}
      })
    .then((response: any) => {
        res.send(response.data.items);
    })
    .catch((error: any) => {
        res.send(error);
    });
});

app.post('/meetings/create', jsonParser, ( req, res ) => {
    // tslint:disable-next-line:no-console
    // console.log(req.body);
    axios({
        method: 'post',
        url: 'https://webexapis.com/v1/meetings',
        headers: {'Content-Type': 'application/json',
         'Authorization': 'Bearer NWYzNWJhZjgtNjc2OC00OWNkLWJkYzMtZWY0ZTYzMDVkODIxN2Q3ZGFmMDctMmM0_P0A1_77d2afa7-517c-48a4-8826-a1e760aefa35'},
        data: { ...req.body }
      })
    .then((response: any) => {
        res.send(response.data.items);
    })
    .catch((error: any) => {
        res.send(error);
    });
});

app.get('/meetings/:id', jsonParser, ( req, res ) => {
    // tslint:disable-next-line:no-console
    // console.log("req.body");
    // tslint:disable-next-line:no-console
    console.log(req.body);
    axios({
        method: 'get',
        url: 'https://webexapis.com/v1/meetings/'+ req.params.id,
        headers: {'Content-Type': 'application/json',
        'Authorization': 'Bearer NWYzNWJhZjgtNjc2OC00OWNkLWJkYzMtZWY0ZTYzMDVkODIxN2Q3ZGFmMDctMmM0_P0A1_77d2afa7-517c-48a4-8826-a1e760aefa35'}
    })
    .then((response: any) => {
        res.send(response.data);
    })
    .catch((error: any) => {
        res.send(error);
    });
});

// start the Express server
app.listen( port, () => {
    // tslint:disable-next-line:no-console
    console.log( `server started at http://localhost:${ port }` );
} );



