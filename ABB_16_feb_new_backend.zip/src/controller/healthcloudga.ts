import { Request, Response, Router } from 'express';
import db  from '../utility/db';

export class HealthCloudga {
    public router: Router;
    // public instance ;

    constructor() {
      this.router = Router();
      this.routes();
      // console.log("init")
    }

	// all(req: Request, res: Response):any{
	// 	db.connection.query("select * from user",(r,v,m) => {
    //         res.send(v);
    //     });
	// }
	// // getuserdetails   /users/1
	// getUserDetails(req: Request, res: Response) {
	// 	var sql = "SELECT * FROM ?? WHERE ?? = ?";
	// 	var inserts = ['user', 'id', req.params.id];
	// 	db.connection.query(sql,inserts,(r,v,m) => {
	// 		res.send(v);
	// 	});
	// }

	// //DELETE FROM table_name WHERE

	// // delete user /users/1
	// deleteUser(req: Request, res: Response) {
	// 	db.connection.query("DELETE from user where id=?",[req.params.id],(r,v,m) => {
	// 		res.send(v);
	// 	});
	// }

	// addUser(req: Request, res: Response) {
	// 	//console.log(req.body);
	// 	//res.send(req.body);
	// 	// const { name, username, address, company, email, phone, website } = req.body;
	// 	// console.log(name, username, address, company, email, phone, website);
	// 	// var sql = "INSERT INTO ?? VALUES (?,?,?,?,?,?,?,?)";
	// 	// var inserts = ['user', db.getUniqueId(), name, username, address, company, email, phone, website];
	// 	// db.connection.query(sql,inserts,(r,v,m) => {
	// 	// 	res.send(v);
    //             // });
    //             var instance = new Razorpay({
    //                     key_id: 'rzp_test_9rl9wF1Xzp1Q8K',
    //                     key_secret: '7pWYtSxytIRT01tJqnAfkwIG',
    //                   });
    //             var options = {
    //                     amount: 100,  // amount in the smallest currency unit
    //                     currency: "INR",
    //                     receipt: "order_rcptid_11",
    //                     payment_capture: '0'
    //                   };
    //                   instance.orders.create(options, function(err, order) {
    //                     console.log(order);
    //                     res.send(order);
    //                   });
	// }


    //     select * from salesforce.healthcloudga__ehrpatient__c
    // select * from salesforce.account a
    // select * from salesforce.healthcloudga__candidatepatient__c
    // select * from salesforce.healthcloudga__ehrcareplan__c hec
    // select healthcloudga__patient__c,* from salesforce.healthcloudga__ehrmedicationprescription__c hec2

    getAllhealthCloudgaEhrpatient(req: Request, res: Response): void {
        // console.log('get All healthCloudga Ehr patient');
        db.query('select ep."name" patname, healthcloudga__name__c, healthcloudga__account__c, a.name accountname from salesforce.healthcloudga__ehrpatient__c ep inner join salesforce.account a on a.sfid = ep.healthcloudga__account__c;', (err: any, resdata: any) => {
            // if (err) throw res.send(err);
            if (resdata) {
                res.send(resdata);
            } else {
                res.send('Data not available');
            }
        });
    }


    getAllHealthCloudAccount(req: Request, res: Response): void {
        db.query('select sfid, name from salesforce.account;', (err: any, resdata: any) => {
            // if (err) throw res.send(err);
            if (resdata && resdata.rows) {
                res.send(resdata.rows);
            } else {
                res.send('Data not available');
            }
        });
    }

    getAllHealthcloudgaCandidatepatient(req: Request, res: Response): void {
        db.query('select * from salesforce.healthcloudga__candidatepatient__c;', (err: any, resdata: any) => {
            // if (err) throw res.send(err);
            if (resdata) {
                res.send(resdata);
            } else {
                res.send('Data not available');
            }
        });
    }

    getAllHealthcloudgaEhrmedicationprescription(req: Request, res: Response): void {
        if (req.query.sfid != null) {
            const textStr = "select a.name accountname,* from salesforce.healthcloudga__ehrmedicationprescription__c hec2 inner join salesforce.account a on a.sfid = hec2.healthcloudga__account__c where hec2.healthcloudga__account__c =$1;";
            const values = [req.query.sfid];
            db.query(textStr, values, (err: any, resdata: any) => {
                if (resdata) {
                    res.send(resdata);
                } else {
                    res.send('Data not available');
                }
            });
        } else {
            db.query('select a.name accountname,* from salesforce.healthcloudga__ehrmedicationprescription__c hec2 inner join salesforce.account a on a.sfid = hec2.healthcloudga__account__c;', (err: any, resdata: any) => {
                if (resdata) {
                    res.send(resdata);
                } else {
                    res.send('Data not available');
                }
            });
        }
    }

    getAllHealthcloudgaEhrcareplan(req: Request, res: Response): void {
        db.query('select * from salesforce.healthcloudga__ehrcareplan__c;', (err: any, resdata: any) => {
            // if (err) throw res.send(err);
            if (resdata) {
                res.send(resdata);
            } else {
                res.send('Data not available');
            }
        });
    }

    addMedicalPrescription(req: Request, res: Response): void {
        // console.log('in addMedicalPrescription');
        const { healthcloudga__medicationname__c,
            healthcloudga__dispensequantityvalue__c, healthcloudga__account__c
            , healthcloudga__dispensevalidityperiodstart__c, healthcloudga__dispensevalidityperiodend__c
            , CreatedById, healthcloudga__datewritten__c, healthcloudga__statuscode__c
            , healthcloudga__dispensemedicationexpiration__c } = req.body;
        // const textStr = "INSERT INTO salesforce.healthcloudga__ehrmedicationprescription__c(healthcloudga__medicationname__c, healthcloudga__dispensequantityvalue__c, healthcloudga__account__c, healthcloudga__dispensevalidityperiodstart__c,healthcloudga__dispensevalidityperiodend__c, CreatedById,healthcloudga__datewritten__c, healthcloudga__statuscode__c, healthcloudga__dispensemedicationexpiration__c, createddate) VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING id";
        const textStr = "select * from salesforce.fn_insert_medication_prescription($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)";
        const values = [healthcloudga__medicationname__c, healthcloudga__dispensequantityvalue__c,
            healthcloudga__account__c, healthcloudga__dispensevalidityperiodstart__c,
            healthcloudga__dispensevalidityperiodend__c, CreatedById, healthcloudga__datewritten__c,
            healthcloudga__statuscode__c, healthcloudga__dispensemedicationexpiration__c, new Date()];

        // console.log(textStr);

        db.query( textStr, values, (err: any, result: any) => {
            if (err) {
                res.send(err.stack)
              } else {
                res.send(result.rows[0])
                // { name: 'brianc', email: 'brian.m.carlson@gmail.com' }
              }
        });
    }

    addMedicationRoutine(req: Request, res: Response): void {
        const { healthcloudga__account__c, healthcloudga__statuscode__c } = req.body;
    }

  // set up our routes
  public routes() {
    this.router.get('/healthcloudgaehrpatient', this.getAllhealthCloudgaEhrpatient);
    this.router.get('/healthCloudAccount', this.getAllHealthCloudAccount);
    this.router.get('/healthcloudgaCandidatepatient', this.getAllHealthcloudgaCandidatepatient);
    this.router.get('/healthcloudgaEhrmedicationprescription', this.getAllHealthcloudgaEhrmedicationprescription);
    this.router.get('/healthcloudgaEhrcareplan', this.getAllHealthcloudgaEhrcareplan);
    this.router.post('/addMedicalPrescription', this.addMedicalPrescription);
    // this.router.get('/:id', this.getUserDetails);
    // this.router.delete('/:id', this.deleteUser);
    // this.router.post('/', this.addUser);
    // this.router.get('/', this.all);
    // this.router.get('/:username', this.one);
    // this.router.post('/', this.create);
    // this.router.put('/:username', this.update);
    // this.router.delete('/:username', this.delete);
  }
}
