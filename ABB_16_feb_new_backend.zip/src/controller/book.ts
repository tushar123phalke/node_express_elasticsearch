import { Request, Response, Router } from 'express';
import db  from '../utility/db';

export class Book {
    public router: Router;
    // public instance ;

    constructor() {
      this.router = Router();
      this.routes();
    }

    getAllBooklist(req: Request, res: Response): void {
        db.query('select * from public.ebooks_data;', (err: any, resdata: any) => {
            // if (err) throw res.send(err);
            if (resdata) {
                res.send(resdata.rows);
            } else {
                res.send('Data not available');
            }
        });
    }

    searchBookDetails(req: Request, res: Response) {
        // tslint:disable-next-line:no-console
        console.log(req.params.book_name);
        const query = {
            text: "select * FROM public.ebooks_data WHERE book_name LIKE $1",
            values: [ '%' + req.params.book_name + '%'],
        };

        db.query(query, (err: any, resdata: any) => {
            if (err) { res.send(err) };
            if (resdata) {
                res.send(resdata.rows);
            } else {
                res.send('Data not available');
            }
        });
	}

    // set up our routes
    public routes() {
     this.router.get('/booklist', this.getAllBooklist);
     this.router.get('/booklist/:book_name', this.searchBookDetails);
    }
}
