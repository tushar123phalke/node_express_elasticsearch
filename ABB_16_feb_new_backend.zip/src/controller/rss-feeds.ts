
import { Request, Response, Router } from 'express';
import db  from '../utility/db';
const Feed = require('rss-to-json');


export class RssFeeds {
    public router: Router;
    // public instance ;

    constructor() {
      this.router = Router();
      this.routes();
    }

    getALlFeedsJSONdata(req: Request, res: Response): void {
        // res.send(req.body.url);
        Feed.load(req.body.url, (err: any, rss: any) => {
            res.send(rss);
        });
    }

    // set up our routes
    public routes() {
    //  this.router.get('/booklist', this.getAllBooklist);
     this.router.post('/getFeedsJSON', this.getALlFeedsJSONdata);
    }
}
