import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgBusyModule} from 'ng-busy';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import bootstrap from "bootstrap";
import { NgxPaginationModule } from 'ngx-pagination';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WebexManagerComponent } from './webex-manager/webex-manager.component';
import { HttpClientModule } from '@angular/common/http';
import { DlDateTimeDateModule, DlDateTimePickerModule } from 'angular-bootstrap-datetimepicker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EBookComponent } from './e-book/e-book.component';
import { EBookElasticsearchComponent } from './e-book-elasticsearch/e-book-elasticsearch.component';
import { NewsComponent } from './news/news.component';


@NgModule({
  declarations: [
    AppComponent,
    WebexManagerComponent,
    EBookComponent,
    EBookElasticsearchComponent,
    NewsComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    DlDateTimeDateModule,
    DlDateTimePickerModule,
    NgBusyModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
