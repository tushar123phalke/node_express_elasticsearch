import { Component, OnInit } from '@angular/core';
import { WebexMeetingService } from '../webex-meeting.service';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.scss']
})
export class NewsComponent implements OnInit {
  public updatedata = 'test1';
  public newsDetails = null;


  public menuList = [{
    display_name: 'All News',
    url: 'https://www.sciencedaily.com/rss/all.xml'
  }, {
    display_name: 'Top News',
    url: 'https://www.sciencedaily.com/rss/top.xml'
  }, {
    display_name: 'Top Science',
    url: 'https://www.sciencedaily.com/rss/top/science.xml'
  }, {
    display_name: 'Top Health',
    url: 'https://www.sciencedaily.com/rss/top/health.xml'
  }, {
    display_name: 'Top Technology',
    url: 'https://www.sciencedaily.com/rss/top/technology.xml'
  }, {
    display_name: 'Top Environment',
    url: 'https://www.sciencedaily.com/rss/top/environment.xml'
  }, {
    display_name: 'Top Society',
    url: 'https://www.sciencedaily.com/rss/top/society.xml'
  }, {
    display_name: 'Strange & Offbeat',
    url: 'https://www.sciencedaily.com/rss/strange_offbeat.xml'
  }, {
    display_name: 'Most Popular',
    url: 'https://www.sciencedaily.com/rss/most_popular.xml'
  }, {
    display_name: 'medicalxpress',
    url: 'https://medicalxpress.com/rss-feed/'
  }];

  constructor(private webexMeetingService: WebexMeetingService) { }

  ngOnInit() {
    this.getNewsDetails('https://www.sciencedaily.com/rss/all.xml');
  }

  onMenuClick(event, val): void {
    this.getNewsDetails(val);
    event.preventDefault();
  }

  getNewsDetails(url): void {
    this.webexMeetingService.getNewsFeeds(url).subscribe((result: any) => {
      console.log(result);
      if (result) {
        this.newsDetails = result;
      }
    }, (err) => console.log(err));
  }
  // getNewsFeeds
}
