import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WebexManagerComponent } from './webex-manager.component';

describe('WebexManagerComponent', () => {
  let component: WebexManagerComponent;
  let fixture: ComponentFixture<WebexManagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WebexManagerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WebexManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
