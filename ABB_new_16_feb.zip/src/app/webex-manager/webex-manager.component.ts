import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { WebexMeetingService } from '../webex-meeting.service';
import * as _ from 'lodash';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { json_data } from '../data/data';

@Component({
  selector: 'app-webex-manager',
  templateUrl: './webex-manager.component.html',
  styleUrls: ['./webex-manager.component.scss']
})
export class WebexManagerComponent implements OnInit {
  public selectedId = 1;
  model: any = {};
  registerForm: FormGroup;
  meetingObj = null;
  submitted = false;
  timezonedata = json_data.timezones;
  public $subscription: Subscription;
  // model: any = {};
  public temasdata = {
    parent: []
  };
  public meetingsdata = {
    parent: []
  };
  constructor(private webexMeetingService: WebexMeetingService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      title: ['', Validators.required],
      agenda: ['', null],
      start: ['', Validators.required],
      end: ['', Validators.required],
      timezone: ['', Validators.required],
      hostEmail: ['', Validators.required],
      // siteUrl: ['', null]
  });
    this.getAllTeamsRecord();
  }

  openDisplayPopup(meeting): void {
    console.log(meeting);
    this.meetingObj = null;
    this.$subscription = this.webexMeetingService.getMeetingDetails(meeting.id).subscribe((v) => {
      this.meetingObj = v;
    });
  }

  onSubmit() {
    this.submitted = true;
    console.log(this.registerForm.controls);

    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }

    let reqbody: any = {
      ...this.registerForm.value,
      start: this.registerForm.value.start.replace('T', ' ').concat(':00'),
      end: this.registerForm.value.end.replace('T', ' ').concat(':00'),
      enabledAutoRecordMeeting: false,
      allowAnyUserToBeCoHost: false
    };

    delete reqbody.__proto__;
    delete reqbody.siteUrl;
    console.log(reqbody);

    this.$subscription = this.webexMeetingService.postNewMeeting(reqbody).subscribe((record) => {
      console.log(record);
      this.handleMeetingData(record);
    });



    // display form values on success
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));
  }

  onReset() {
      this.submitted = false;
      this.registerForm.reset();
  }

  get f() { return this.registerForm.controls; }

  sideMenuHandler(id): void {
    this.selectedId = id;
    switch (id) {
      case 1:
        this.getAllTeamsRecord();
        break;
      case 2:
          // this.getAllRoomsRecord();
          this.getAllMeetings();
          break;
      default:
        break;
    }
  }

  getAllTeamsRecord(): void  {
    this.$subscription = this.webexMeetingService.getAllTeamsData().subscribe((record) => {
      console.log(record);
      this.handleData(record);
    });
  }

  handleData(record): void {
    /*const finalArray = _.filter(record, (o) =>  o.isLocked);
    console.log(finalArray);
    _.each(finalArray, (v) => {
      v.child = _.filter(record,  (k) => {
        return (k.teamId === v.teamId && !k.isLocked) ? true : false;
      });
    });
    console.log(finalArray);*/
    this.temasdata.parent = [];
    this.temasdata.parent = record;
    console.log( this.temasdata.parent);
  }

  getAllRoomsRecord(): void {

  }

  getAllMeetings(): void {
    this.$subscription = this.webexMeetingService.getAllMeetings().subscribe((record) => {
      console.log(record);
      this.handleMeetingData(record);
    });
  }

  handleMeetingData(record): void {
    /*const finalArray = _.filter(record, (o) =>  o.isLocked);
    console.log(finalArray);
    _.each(finalArray, (v) => {
      v.child = _.filter(record,  (k) => {
        return (k.teamId === v.teamId && !k.isLocked) ? true : false;
      });
    });
    console.log(finalArray);*/
    this.meetingsdata.parent = [];
    this.meetingsdata.parent = record;
    // console.log( this.meetingsdata.parent);
  }
}


// "title": "Example Daily Meeting",
//     "agenda": "Example Agenda",
//     "password": "BgJep@43",
//     "start": "2019-11-01 20:00:00",
//     "end": "2019-11-01 21:00:00",
//     "timezone": "Asia/Shanghai",
//     "recurrence": "FREQ=DAILY;INTERVAL=1;COUNT=10",
//     "enabledAutoRecordMeeting": false,
//     "allowAnyUserToBeCoHost": false,
//     "invitees": [
//         {
//             "email": "john.andersen@example.com",
//             "displayName": "John Andersen",
//             "coHost": false
//         },
//         {
//             "email": "brenda.song@example.com",
//             "displayName": "Brenda Song",
//             "coHost": false
//         }
//     ],
//     "hostEmail": "john.andersen@example.com",
//     "siteUrl": "site4-example.webex.com"
