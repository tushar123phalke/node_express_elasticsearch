import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class WebexMeetingService {
  public baseUrl = 'http://localhost:8084';
  constructor(private http: HttpClient) { }

  getAllTeamsData(): Observable<any> {
    return this.http.get<any>( `${this.baseUrl}/teams`);
  }

  getAllMeetings(): Observable<any> {
    return this.http.get<any>( `${this.baseUrl}/meetings`);
  }

  postNewMeeting(data): Observable<any> {
    console.log(data);
    return this.http.post( `${this.baseUrl}/meetings/create`, data);
  }

  getMeetingDetails(id): Observable<any> {
    return this.http.get( `${this.baseUrl}/meetings/${id}`);
  }

  getALLbookList(): Observable<any> {
    return this.http.get( `${this.baseUrl}/booksdetails/booklist`);
  }


  getALLElasticSearchbookList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/books/getall`);
  }

  getSearchBookList(searchText: string): Observable<any> {
    return this.http.get( `${this.baseUrl}/booksdetails/booklist/${searchText}`);
  }

  getElasticSearchBookList(searchText: string): Observable<any> {
    return this.http.get( `${this.baseUrl}/searchitem/${searchText}`);
  }
  getNewsFeeds(data): Observable<any> {
    console.log(data);
    const reqBody = {
      url: data
    };
    return this.http.post( `${this.baseUrl}/feeds/getFeedsJSON`, reqBody);
  }
}
