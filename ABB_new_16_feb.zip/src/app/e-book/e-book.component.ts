import { Component, OnInit } from '@angular/core';
import { WebexMeetingService } from '../webex-meeting.service';

@Component({
  selector: 'app-e-book',
  templateUrl: './e-book.component.html',
  styleUrls: ['./e-book.component.scss']
})
export class EBookComponent implements OnInit {

  public bookslist  = [];
  constructor(private webexMeetingService: WebexMeetingService) { }

  ngOnInit() {
    this.getAllBooks();
  }

  getAllBooks(): void {
    this.webexMeetingService.getALLbookList().subscribe((result) => {
      this.bookslist = result;
      console.log(this.bookslist);
    }, (error) => console.log(error));
  }

  searchBykeyword(e): void {
    const searchText = (e.target.value) ? e.target.value : '';
    this.webexMeetingService.getSearchBookList(searchText).subscribe((result) => {
      this.bookslist = result;
    }, (error) => console.log(error));
  }



}
