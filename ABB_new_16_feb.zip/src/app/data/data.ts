export const json_data = {
  "timezones": [
    {
      "jodaId": "Pacific/Pago_Pago",
      "webexTimezoneId": 1,
      "offset": "-11:00",
      "jodaLongName": "Samoa Standard Time"
    },
    {
      "jodaId": "Pacific/Honolulu",
      "webexTimezoneId": 2,
      "offset": "-10:00",
      "jodaLongName": "Hawaii Standard Time"
    },
    {
      "jodaId": "America/Anchorage",
      "webexTimezoneId": 3,
      "offset": "-09:00",
      "jodaLongName": "Alaska Standard Time"
    },
    {
      "jodaId": "America/Los_Angeles",
      "webexTimezoneId": 4,
      "offset": "-08:00",
      "jodaLongName": "Pacific Standard Time"
    },
    {
      "jodaId": "America/Tijuana",
      "webexTimezoneId": 131,
      "offset": "-08:00",
      "jodaLongName": "Pacific Standard Time"
    },
    {
      "jodaId": "America/Phoenix",
      "webexTimezoneId": 5,
      "offset": "-07:00",
      "jodaLongName": "Mountain Standard Time"
    },
    {
      "jodaId": "America/Chihuahua",
      "webexTimezoneId": 132,
      "offset": "-07:00",
      "jodaLongName": "Mountain Standard Time"
    },
    {
      "jodaId": "America/Denver",
      "webexTimezoneId": 6,
      "offset": "-07:00",
      "jodaLongName": "Mountain Standard Time"
    },
    {
      "jodaId": "America/Hermosillo",
      "webexTimezoneId": 159,
      "offset": "-07:00",
      "jodaLongName": "Mountain Standard Time"
    },
    {
      "jodaId": "America/Chicago",
      "webexTimezoneId": 7,
      "offset": "-06:00",
      "jodaLongName": "Central Standard Time"
    },
    {
      "jodaId": "America/Mexico_City",
      "webexTimezoneId": 8,
      "offset": "-06:00",
      "jodaLongName": "Central Standard Time"
    },
    {
      "jodaId": "America/Regina",
      "webexTimezoneId": 9,
      "offset": "-06:00",
      "jodaLongName": "Central Standard Time"
    },
    {
      "jodaId": "America/Tegucigalpa",
      "webexTimezoneId": 137,
      "offset": "-06:00",
      "jodaLongName": "Central Standard Time"
    },
    {
      "jodaId": "America/Bogota",
      "webexTimezoneId": 10,
      "offset": "-05:00",
      "jodaLongName": "Colombia Time"
    },
    {
      "jodaId": "America/Los_Angeles",
      "webexTimezoneId": 160,
      "offset": "-08:00",
      "jodaLongName": "Pacific Standard Time"
    },
    {
      "jodaId": "America/Indiana/Indianapolis",
      "webexTimezoneId": 12,
      "offset": "-05:00",
      "jodaLongName": "Eastern Standard Time"
    },
    {
      "jodaId": "America/New_York",
      "webexTimezoneId": 11,
      "offset": "-05:00",
      "jodaLongName": "Eastern Standard Time"
    },
    {
      "jodaId": "America/Panama",
      "webexTimezoneId": 146,
      "offset": "-05:00",
      "jodaLongName": "Eastern Standard Time"
    },
    {
      "jodaId": "America/Toronto",
      "webexTimezoneId": 158,
      "offset": "-05:00",
      "jodaLongName": "Eastern Standard Time"
    },
    {
      "jodaId": "America/Caracas",
      "webexTimezoneId": 133,
      "offset": "-04:00",
      "jodaLongName": "Venezuela Time"
    },
    {
      "jodaId": "America/Halifax",
      "webexTimezoneId": 13,
      "offset": "-04:00",
      "jodaLongName": "Atlantic Standard Time"
    },
    {
      "jodaId": "America/La_Paz",
      "webexTimezoneId": 14,
      "offset": "-04:00",
      "jodaLongName": "Bolivia Time"
    },
    {
      "jodaId": "America/St_Johns",
      "webexTimezoneId": 15,
      "offset": "-03:30",
      "jodaLongName": "Newfoundland Standard Time"
    },
    {
      "jodaId": "America/Asuncion",
      "webexTimezoneId": 148,
      "offset": "-03:00",
      "jodaLongName": "Paraguay Summer Time"
    },
    {
      "jodaId": "America/Sao_Paulo",
      "webexTimezoneId": 16,
      "offset": "-03:00",
      "jodaLongName": "Brasilia Time"
    },
    {
      "jodaId": "America/Argentina/Buenos_Aires",
      "webexTimezoneId": 17,
      "offset": "-03:00",
      "jodaLongName": "Argentine Time"
    },
    {
      "jodaId": "America/Montevideo",
      "webexTimezoneId": 149,
      "offset": "-03:00",
      "jodaLongName": "Uruguay Time"
    },
    {
      "jodaId": "America/Nuuk",
      "webexTimezoneId": 138,
      "offset": "-03:00",
      "jodaLongName": "Western Greenland Time"
    },
    {
      "jodaId": "America/Recife",
      "webexTimezoneId": 135,
      "offset": "-03:00",
      "jodaLongName": "Brasilia Time"
    },
    {
      "jodaId": "America/Santiago",
      "webexTimezoneId": 145,
      "offset": "-03:00",
      "jodaLongName": "Chile Summer Time"
    },
    {
      "jodaId": "Atlantic/South_Georgia",
      "webexTimezoneId": 18,
      "offset": "-02:00",
      "jodaLongName": "South Georgia Standard Time"
    },
    {
      "jodaId": "Atlantic/Azores",
      "webexTimezoneId": 19,
      "offset": "-01:00",
      "jodaLongName": "Azores Time"
    },
    {
      "jodaId": "Atlantic/Cape_Verde",
      "webexTimezoneId": 150,
      "offset": "-01:00",
      "jodaLongName": "Cape Verde Time"
    },
    {
      "jodaId": "Europe/London",
      "webexTimezoneId": 21,
      "offset": "+00:00",
      "jodaLongName": "Greenwich Mean Time"
    },
    {
      "jodaId": "Atlantic/Reykjavik",
      "webexTimezoneId": 20,
      "offset": "+00:00",
      "jodaLongName": "Greenwich Mean Time"
    },
    {
      "jodaId": "Europe/Amsterdam",
      "webexTimezoneId": 22,
      "offset": "+01:00",
      "jodaLongName": "Central European Time"
    },
    {
      "jodaId": "Europe/Berlin",
      "webexTimezoneId": 25,
      "offset": "+01:00",
      "jodaLongName": "Central European Time"
    },
    {
      "jodaId": "Europe/Brussels",
      "webexTimezoneId": 147,
      "offset": "+01:00",
      "jodaLongName": "Central European Time"
    },
    {
      "jodaId": "Africa/Casablanca",
      "webexTimezoneId": 136,
      "offset": "+01:00",
      "jodaLongName": "Western European Summer Time"
    },
    {
      "jodaId": "Europe/Madrid",
      "webexTimezoneId": 144,
      "offset": "+01:00",
      "jodaLongName": "Central European Time"
    },
    {
      "jodaId": "Europe/Oslo",
      "webexTimezoneId": 129,
      "offset": "+01:00",
      "jodaLongName": "Central European Time"
    },
    {
      "jodaId": "Europe/Paris",
      "webexTimezoneId": 23,
      "offset": "+01:00",
      "jodaLongName": "Central European Time"
    },
    {
      "jodaId": "Europe/Prague",
      "webexTimezoneId": 24,
      "offset": "+01:00",
      "jodaLongName": "Central European Time"
    },
    {
      "jodaId": "Europe/Rome",
      "webexTimezoneId": 142,
      "offset": "+01:00",
      "jodaLongName": "Central European Time"
    },
    {
      "jodaId": "Europe/Stockholm",
      "webexTimezoneId": 130,
      "offset": "+01:00",
      "jodaLongName": "Central European Time"
    },
    {
      "jodaId": "Africa/Lagos",
      "webexTimezoneId": 143,
      "offset": "+01:00",
      "jodaLongName": "Western African Time"
    },
    {
      "jodaId": "Asia/Amman",
      "webexTimezoneId": 139,
      "offset": "+02:00",
      "jodaLongName": "Eastern European Time"
    },
    {
      "jodaId": "Europe/Athens",
      "webexTimezoneId": 26,
      "offset": "+02:00",
      "jodaLongName": "Eastern European Time"
    },
    {
      "jodaId": "Europe/Chisinau",
      "webexTimezoneId": 27,
      "offset": "+02:00",
      "jodaLongName": "Eastern European Time"
    },
    {
      "jodaId": "Europe/Bucharest",
      "webexTimezoneId": 157,
      "offset": "+02:00",
      "jodaLongName": "Eastern European Time"
    },
    {
      "jodaId": "Africa/Cairo",
      "webexTimezoneId": 28,
      "offset": "+02:00",
      "jodaLongName": "Eastern European Time"
    },
    {
      "jodaId": "Europe/Helsinki",
      "webexTimezoneId": 30,
      "offset": "+02:00",
      "jodaLongName": "Eastern European Time"
    },
    {
      "jodaId": "Africa/Johannesburg",
      "webexTimezoneId": 29,
      "offset": "+02:00",
      "jodaLongName": "South Africa Standard Time"
    },
    {
      "jodaId": "Asia/Jerusalem",
      "webexTimezoneId": 31,
      "offset": "+02:00",
      "jodaLongName": "Israel Standard Time"
    },
    {
      "jodaId": "Africa/Windhoek",
      "webexTimezoneId": 151,
      "offset": "+02:00",
      "jodaLongName": "Central African Summer Time"
    },
    {
      "jodaId": "Europe/Istanbul",
      "webexTimezoneId": 140,
      "offset": "+03:00",
      "jodaLongName": "Turkey Time"
    },
    {
      "jodaId": "Europe/Moscow",
      "webexTimezoneId": 33,
      "offset": "+03:00",
      "jodaLongName": "Moscow Standard Time"
    },
    {
      "jodaId": "Africa/Nairobi",
      "webexTimezoneId": 34,
      "offset": "+03:00",
      "jodaLongName": "Eastern African Time"
    },
    {
      "jodaId": "Asia/Riyadh",
      "webexTimezoneId": 32,
      "offset": "+03:00",
      "jodaLongName": "Arabia Standard Time"
    },
    {
      "jodaId": "Asia/Tehran",
      "webexTimezoneId": 35,
      "offset": "+03:30",
      "jodaLongName": "Iran Standard Time"
    },
    {
      "jodaId": "Asia/Muscat",
      "webexTimezoneId": 36,
      "offset": "+04:00",
      "jodaLongName": "Gulf Standard Time"
    },
    {
      "jodaId": "Asia/Baku",
      "webexTimezoneId": 37,
      "offset": "+04:00",
      "jodaLongName": "Azerbaijan Time"
    },
    {
      "jodaId": "Asia/Yerevan",
      "webexTimezoneId": 155,
      "offset": "+04:00",
      "jodaLongName": "Armenia Time"
    },
    {
      "jodaId": "Asia/Kabul",
      "webexTimezoneId": 38,
      "offset": "+04:30",
      "jodaLongName": "Afghanistan Time"
    },
    {
      "jodaId": "Asia/Karachi",
      "webexTimezoneId": 40,
      "offset": "+05:00",
      "jodaLongName": "Pakistan Time"
    },
    {
      "jodaId": "Asia/Yekaterinburg",
      "webexTimezoneId": 39,
      "offset": "+05:00",
      "jodaLongName": "Yekaterinburg Time"
    },
    {
      "jodaId": "Asia/Colombo",
      "webexTimezoneId": 42,
      "offset": "+05:30",
      "jodaLongName": "India Standard Time"
    },
    {
      "jodaId": "Asia/Kolkata",
      "webexTimezoneId": 41,
      "offset": "+05:30",
      "jodaLongName": "India Standard Time"
    },
    {
      "jodaId": "Asia/Kathmandu",
      "webexTimezoneId": 141,
      "offset": "+05:45",
      "jodaLongName": "Nepal Time"
    },
    {
      "jodaId": "Asia/Almaty",
      "webexTimezoneId": 43,
      "offset": "+06:00",
      "jodaLongName": "Alma-Ata Time"
    },
    {
      "jodaId": "Asia/Yangon",
      "webexTimezoneId": 152,
      "offset": "+06:30",
      "jodaLongName": "Myanmar Time"
    },
    {
      "jodaId": "Asia/Bangkok",
      "webexTimezoneId": 44,
      "offset": "+07:00",
      "jodaLongName": "Indochina Time"
    },
    {
      "jodaId": "Asia/Jakarta",
      "webexTimezoneId": 154,
      "offset": "+07:00",
      "jodaLongName": "West Indonesia Time"
    },
    {
      "jodaId": "Asia/Novosibirsk",
      "webexTimezoneId": 156,
      "offset": "+07:00",
      "jodaLongName": "Novosibirsk Time"
    },
    {
      "jodaId": "Asia/Shanghai",
      "webexTimezoneId": 45,
      "offset": "+08:00",
      "jodaLongName": "China Standard Time"
    },
    {
      "jodaId": "Asia/Kuala_Lumpur",
      "webexTimezoneId": 134,
      "offset": "+08:00",
      "jodaLongName": "Malaysia Time"
    },
    {
      "jodaId": "Australia/Perth",
      "webexTimezoneId": 46,
      "offset": "+08:00",
      "jodaLongName": "Australian Western Standard Time"
    },
    {
      "jodaId": "Asia/Singapore",
      "webexTimezoneId": 47,
      "offset": "+08:00",
      "jodaLongName": "Singapore Time"
    },
    {
      "jodaId": "Asia/Taipei",
      "webexTimezoneId": 48,
      "offset": "+08:00",
      "jodaLongName": "China Standard Time"
    },
    {
      "jodaId": "Asia/Seoul",
      "webexTimezoneId": 50,
      "offset": "+09:00",
      "jodaLongName": "Korea Standard Time"
    },
    {
      "jodaId": "Asia/Tokyo",
      "webexTimezoneId": 49,
      "offset": "+09:00",
      "jodaLongName": "Japan Standard Time"
    },
    {
      "jodaId": "Asia/Yakutsk",
      "webexTimezoneId": 51,
      "offset": "+09:00",
      "jodaLongName": "Yakutsk Time"
    },
    {
      "jodaId": "Australia/Darwin",
      "webexTimezoneId": 53,
      "offset": "+09:30",
      "jodaLongName": "Australian Central Standard Time (Northern Territory)"
    },
    {
      "jodaId": "Australia/Brisbane",
      "webexTimezoneId": 54,
      "offset": "+10:00",
      "jodaLongName": "Australian Eastern Standard Time (Queensland)"
    },
    {
      "jodaId": "Pacific/Guam",
      "webexTimezoneId": 56,
      "offset": "+10:00",
      "jodaLongName": "Chamorro Standard Time"
    },
    {
      "jodaId": "Asia/Vladivostok",
      "webexTimezoneId": 58,
      "offset": "+10:00",
      "jodaLongName": "Vladivostok Time"
    },
    {
      "jodaId": "Australia/Adelaide",
      "webexTimezoneId": 52,
      "offset": "+10:30",
      "jodaLongName": "Australian Central Daylight Time (South Australia)"
    },
    {
      "jodaId": "Australia/Hobart",
      "webexTimezoneId": 57,
      "offset": "+11:00",
      "jodaLongName": "Australian Eastern Daylight Time (Tasmania)"
    },
    {
      "jodaId": "Pacific/Guadalcanal",
      "webexTimezoneId": 59,
      "offset": "+11:00",
      "jodaLongName": "Solomon Is. Time"
    },
    {
      "jodaId": "Australia/Sydney",
      "webexTimezoneId": 55,
      "offset": "+11:00",
      "jodaLongName": "Australian Eastern Daylight Time (New South Wales)"
    },
    {
      "jodaId": "Pacific/Fiji",
      "webexTimezoneId": 61,
      "offset": "+12:00",
      "jodaLongName": "Fiji Time"
    },
    {
      "jodaId": "Etc/GMT+12",
      "webexTimezoneId": 0,
      "offset": "-12:00",
      "jodaLongName": "-12:00"
    },
    {
      "jodaId": "Pacific/Tongatapu",
      "webexTimezoneId": 153,
      "offset": "+13:00",
      "jodaLongName": "Tonga Time"
    },
    {
      "jodaId": "Pacific/Auckland",
      "webexTimezoneId": 60,
      "offset": "+13:00",
      "jodaLongName": "New Zealand Daylight Time"
    }
  ],
  "locales": [
    {
      "language": "es_ES",
      "regions": [
        "ES",
        "AR",
        "CL",
        "CO",
        "MX",
        "VE"
      ]
    },
    {
      "language": "zh_CN",
      "regions": [
        "CN",
        "HK"
      ]
    },
    {
      "language": "sv_SE",
      "regions": [
        "SE",
        "AU",
        "CA",
        "XF",
        "FR",
        "NZ",
        "CH",
        "GB",
        "US"
      ]
    },
    {
      "language": "ja_JP",
      "regions": [
        "JP"
      ]
    },
    {
      "language": "ko_KR",
      "regions": [
        "KR"
      ]
    },
    {
      "language": "es_MX",
      "regions": [
        "MX",
        "AR",
        "CL",
        "CO",
        "ES",
        "US",
        "VE"
      ]
    },
    {
      "language": "nl_NL",
      "regions": [
        "BE",
        "NL"
      ]
    },
    {
      "language": "ru_RU",
      "regions": [
        "RU"
      ]
    },
    {
      "language": "zh_TW",
      "regions": [
        "TW",
        "HK"
      ]
    },
    {
      "language": "pt_BR",
      "regions": [
        "BR",
        "PT"
      ]
    },
    {
      "language": "de_DE",
      "regions": [
        "DE",
        "AU",
        "CA",
        "XF",
        "FR",
        "NZ",
        "SE",
        "CH",
        "GB",
        "US"
      ]
    },
    {
      "language": "da_DK",
      "regions": [
        "DK"
      ]
    },
    {
      "language": "tr_TR",
      "regions": [
        "TR"
      ]
    },
    {
      "language": "it_IT",
      "regions": [
        "IT"
      ]
    },
    {
      "language": "fr_FR",
      "regions": [
        "FR",
        "XF",
        "AU",
        "CA",
        "DE",
        "NZ",
        "SE",
        "CH",
        "US",
        "GB"
      ]
    },
    {
      "language": "en_US",
      "regions": [
        "US",
        "AU",
        "CA",
        "XF",
        "FR",
        "DE",
        "NZ",
        "SE",
        "CH",
        "GB"
      ]
    }
  ]
}
